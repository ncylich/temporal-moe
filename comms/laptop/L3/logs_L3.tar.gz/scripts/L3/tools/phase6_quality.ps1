# Phase 6: loss in nats/token of the Q4_0 file under trained routing on the first 512 test samples
# (2048 tokens each, 1,048,576 tokens), with the Windows engine DLLs that were timed (C:\tmoe\bin-trained),
# flash attention on and F16 KV as on the phone (engine defaults), 8 threads. Same tool and arguments as
# the phone ledger step 7: gguf_logits nll ... fa kvf16 threads=N.
$ErrorActionPreference = 'Stop'
$BT = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools'
$clang = Join-Path $BT 'VC\Tools\Llvm\x64\bin\clang-cl.exe'
$src = 'C:\tmoe\temporal-moe\scripts\serving_convert\gguf_logits.cpp'
$L = 'C:\tmoe\llama.cpp'
$bin = 'C:\tmoe\bin-trained'
$work = 'C:\tmoe\work\fine_1e19'
New-Item -ItemType Directory -Force $work | Out-Null
Set-Location $work                                   # compiler objects land here, inside C:\tmoe
"=== $(Get-Date -Format s) compile gguf_logits.exe against build-win-trained (llama.lib -> llama.dll in $bin)"
# vcvars for the MSVC libs and headers clang-cl links against
$vc = Join-Path $BT 'VC\Auxiliary\Build\vcvars64.bat'
$ErrorActionPreference = 'Continue'
cmd /c "`"$vc`" >nul 2>nul && `"$clang`" /nologo /std:c++17 /O2 /EHsc /MD /I $L\include /I $L\ggml\include $src /Fe:$bin\gguf_logits.exe /link $L\build-win-trained\src\Release\llama.lib"
if ($LASTEXITCODE -ne 0) { throw "compile rc=$LASTEXITCODE" }
$ErrorActionPreference = 'Stop'
Remove-Item -ErrorAction SilentlyContinue gguf_logits.obj
Get-FileHash "$bin\gguf_logits.exe" -Algorithm SHA256 | Format-List | Out-String
"=== $(Get-Date -Format s) rows file from WSL"
Copy-Item '\\wsl.localhost\Ubuntu-24.04\home\mohsen\tmoe\work\fine_1e19\rows512.i32' "$work\rows512.i32" -Force
(Get-Item "$work\rows512.i32").Length
"=== $(Get-Date -Format s) nll, 512 rows x 2048, Q4_0, trained routing, fa, kvf16, threads=8"
$env:LLAMA_TEMPORAL_ROUTE = 'trained'
$t0 = Get-Date
$ErrorActionPreference = 'Continue'
& "$bin\gguf_logits.exe" nll C:\tmoe\models\fine_1e19-q4_0.gguf "$work\rows512.i32" 512 2048 "$work\nll_win_q4_512.f32" fa kvf16 threads=8 2> "$work\nll_win_q4_512.stderr"
"rc=$LASTEXITCODE wall_s=$(((Get-Date) - $t0).TotalSeconds)"
Select-String -Path "$work\nll_win_q4_512.stderr" -Pattern 'temporal-route|error' | ForEach-Object { $_.Line }
"=== $(Get-Date -Format s) PHASE6 DONE"
