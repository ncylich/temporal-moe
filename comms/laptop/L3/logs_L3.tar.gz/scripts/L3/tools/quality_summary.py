"""Phase 6 summary: mean loss (nats/token) of the per-token NLL file, standard error over samples, and the
comparison with the PyTorch reference (3.19202) and the phone ledger's Q4_0 numbers (step 7)."""
import array, json, math, sys
from pathlib import Path

nll, n_rows, seq, out = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), Path(sys.argv[4])
a = array.array("f"); a.frombytes(nll.read_bytes())
assert len(a) == n_rows * seq, (len(a), n_rows * seq)
rows = [sum(a[i * seq:(i + 1) * seq]) / seq for i in range(n_rows)]
mean = sum(rows) / n_rows
sd = math.sqrt(sum((r - mean) ** 2 for r in rows) / (n_rows - 1))
se = sd / math.sqrt(n_rows)
REF, PHONE_Q4, HOST_Q4, HOST_F16 = 3.19202, 3.21334, 3.21330, 3.19221
d = {"rows": n_rows, "tokens": n_rows * seq, "loss_nats_per_token": mean, "bits_per_byte": mean / 2.9780,
     "se_over_samples": se, "sd_over_samples": sd, "minus_reference": mean - REF, "minus_phone_q4_0": mean - PHONE_Q4,
     "minus_host_q4_0": mean - HOST_Q4, "minus_host_f16": mean - HOST_F16,
     "reference": REF, "phone_q4_0": PHONE_Q4, "host_q4_0": HOST_Q4, "host_f16": HOST_F16,
     "first_rows": [round(x, 5) for x in rows[:4]], "nonfinite": sum(1 for x in a if not math.isfinite(x))}
out.write_text(json.dumps(d, indent=1))
print(json.dumps(d, indent=1))
