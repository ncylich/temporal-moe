#!/bin/bash
# Phase 1 (WSL side): Python deps, patched engine host build, weights extraction, GGUF, Q4_0.
# Everything under ~/tmoe. Patches are read from the Windows clone of the repo.
set -euo pipefail
T=~/tmoe
WORK=$T/work/fine_1e19
REPO=$T/temporal-moe
LLAMA=$T/llama.cpp-trained
PATCHDIR=/mnt/c/tmoe/temporal-moe/scripts/serving_convert/engine_patch
mkdir -p $WORK
stamp() { echo "=== $(date -Is) $*"; }

stamp "python deps"
$T/venv/bin/pip install -q --upgrade pip
$T/venv/bin/pip install -q torch --index-url https://download.pytorch.org/whl/cpu
$T/venv/bin/pip install -q safetensors huggingface_hub tokenizers requests numpy
$T/venv/bin/python -c "import torch, numpy, safetensors, huggingface_hub, tokenizers; print('torch', torch.__version__, 'numpy', numpy.__version__)"

stamp "repo clone in WSL -> laptop-trained-model"
git -C $REPO fetch -q origin laptop-trained-model
git -C $REPO checkout -q -B laptop-trained-model origin/laptop-trained-model
git -C $REPO log --oneline -1

stamp "engine: 43bec5f3 + trained-routing patches"
if [ ! -d $LLAMA ]; then
  git clone -q $T/llama.cpp $LLAMA
  git -C $LLAMA remote set-url origin https://github.com/ncylich/llama.cpp.git
fi
git -C $LLAMA fetch -q origin temporal-moe-win
if ! git -C $LLAMA rev-parse -q --verify temporal-moe-trained-routing >/dev/null; then
  git -C $LLAMA checkout -q -b temporal-moe-trained-routing 43bec5f3
  git -C $LLAMA -c user.name="Mohsen Fayyaz" -c user.email="laptop@localhost" am -q $PATCHDIR/000*.patch
fi
git -C $LLAMA log --oneline -3
echo "tree $(git -C $LLAMA rev-parse --short=8 HEAD^{tree}) (patch README: b69151b6)"

stamp "engine host build (Linux, native)"
cmake -S $LLAMA -B $LLAMA/build-host -DCMAKE_BUILD_TYPE=Release -DGGML_NATIVE=ON -DLLAMA_CURL=OFF -DBUILD_SHARED_LIBS=ON > $T/logs/trained_cmake.log 2>&1
cmake --build $LLAMA/build-host -j 8 --target llama llama-quantize llama-perplexity llama-bench > $T/logs/trained_build.log 2>&1
ls $LLAMA/build-host/bin | head -40
g++ -std=c++17 -O2 $REPO/scripts/serving_convert/gguf_logits.cpp -I $LLAMA/include -I $LLAMA/ggml/include \
    -L $LLAMA/build-host/bin -lllama -Wl,-rpath,$LLAMA/build-host/bin -o $WORK/gguf_logits
echo gguf_logits built

stamp "step 1: weights"
cd $REPO
if [ ! -f $WORK/fine_1e19.safetensors ]; then
  $T/venv/bin/python scripts/serving_convert/dcp_extract.py --run temporal_fine_g3_1e19 --iter 4278 --out $WORK/fine_1e19
fi
ls -l $WORK

stamp "step 3: GGUF f16 and f32"
[ -f $WORK/fine_1e19-f16.gguf ] || $T/venv/bin/python scripts/serving_convert/to_gguf.py --llama-cpp $LLAMA --weights $WORK/fine_1e19.safetensors --topk 18 --out $WORK/fine_1e19-f16.gguf
[ -f $WORK/fine_1e19-f32.gguf ] || $T/venv/bin/python scripts/serving_convert/to_gguf.py --llama-cpp $LLAMA --weights $WORK/fine_1e19.safetensors --topk 18 --ftype f32 --out $WORK/fine_1e19-f32.gguf

stamp "step 4: Q4_0"
[ -f $WORK/fine_1e19-q4_0.gguf ] || $LLAMA/build-host/bin/llama-quantize --pure $WORK/fine_1e19-f16.gguf $WORK/fine_1e19-q4_0.gguf Q4_0 > $T/logs/trained_quantize.log 2>&1
$T/venv/bin/python scripts/serving_convert/gguf_types.py --llama-cpp $LLAMA $WORK/fine_1e19-q4_0.gguf || true
stat -c '%n %s' $WORK/*.gguf
sha256sum $WORK/*.gguf
stamp "PHASE1 WSL DONE"
