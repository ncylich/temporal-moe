"""Phase 2/3 smoke (not timed, host not quiet): each trained arm uncapped at depth 0 and 2048, to read the
route line, pool counters, peak working set and peak commit. Uses lapbench's own engine runner."""
import json, sys
sys.argv = ["lapbench"]
sys.path.insert(0, r"C:\tmoe\temporal-moe\laptopbench")
import lapbench as L

L.apply_model("trained_fine")
L.WINDOWS, L.TARGET, L._TAG = True, "windows", "L3smoke"
L.CURRENT_CAP = None
out = []
n = int(sys.argv[1]) if len(sys.argv) > 1 else 32
for depth in (0, 2048):
    for key in ("a", "b", "c"):
        tier, label, R, tp, cap, extra, norep = L.ARMS[key]
        flags = L.arm_flags(R, tp, extra, no_repack=norep)
        m = L.engine_run_windows(f"smoke_{label}_d{depth}", flags, f"-t 4 -p 0 -n 64 -r 1 -mmp 0 -ot _exps=CPU -d {depth}")
        p = m.get("pool") or {}
        rec = {"arm": key, "label": label, "depth": depth, "rc": m["rc"], "tok_s": m.get("decode_tps"),
               "peak_wset_mib": round(m.get("vmhwm_mib") or 0), "decode_wset_mib": round(m.get("wset_last_mib") or 0),
               "peak_commit_mib": round(m.get("peak_commit_mib") or 0), "fetches": p.get("fetches"),
               "fetched_mib": p.get("fetched_mib"), "evictions": p.get("evictions"), "swaps": p.get("swaps"),
               "R_active": p.get("R_active"), "route": (p.get("route") or {}).get("raw")}
        print(json.dumps(rec), flush=True)
        out.append(rec)
json.dump(out, open(L.RESULTS / "smoke_L3.json", "w"), indent=1)
