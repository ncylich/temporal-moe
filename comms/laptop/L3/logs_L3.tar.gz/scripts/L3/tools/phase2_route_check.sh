#!/bin/bash
# Phase 2 (WSL): engine trained routing vs the PyTorch reference on the F32 file, 4 rows x 2048 tokens.
set -euo pipefail
T=~/tmoe; W=$T/work/fine_1e19; REPO=$T/temporal-moe; PY=$T/venv/bin/python
cd $W
echo "=== $(date -Is) rows file"
$PY - <<'EOF'
import numpy as np
t = np.load("test_tokens.npz")["tokens"].astype(np.int32)
t[:4].tofile("rows4.i32"); t.tofile("rows512.i32")
print("rows4", t[:4].shape, "rows512", t.shape)
EOF
echo "=== $(date -Is) engine F32, trained routing, plain attention, F32 KV"
rm -f route_f32_4.bin
LLAMA_TEMPORAL_ROUTE=trained LLAMA_TEMPORAL_ROUTE_DUMP=route_f32_4.bin \
  ./gguf_logits nll fine_1e19-f32.gguf rows4.i32 4 2048 nll_f32_4.f32 threads=8 2>&1 | grep -E "temporal-route|error|Error" || true
ls -l route_f32_4.bin nll_f32_4.f32
echo "=== $(date -Is) check_engine_routing"
$PY $REPO/scripts/serving_convert/check_engine_routing.py --weights fine_1e19.safetensors \
  --tokens test_tokens.npz --rows 4 --dump route_f32_4.bin --nll nll_f32_4.f32
echo "=== $(date -Is) PHASE2 ROUTE CHECK DONE"
