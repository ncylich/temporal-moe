# Phase 1 (Windows side): build the patched engine natively as in L1-3, into its own build dir and bin dir.
$ErrorActionPreference = 'Stop'
$BT = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools'
$cmake = Join-Path $BT 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
$src = 'C:\tmoe\llama.cpp'
$bld = 'C:\tmoe\llama.cpp\build-win-trained'
$bin = 'C:\tmoe\bin-trained'
"=== $(Get-Date -Format s) fork: $(git -C $src log -1 --format='%h %s') branch: $(git -C $src branch --show-current)"
& $cmake -S $src -B $bld -G 'Visual Studio 17 2022' -A x64 -T ClangCL -DCMAKE_BUILD_TYPE=Release -DGGML_NATIVE=ON -DLLAMA_CURL=OFF -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_EXAMPLES=OFF -DLLAMA_BUILD_SERVER=OFF
if ($LASTEXITCODE -ne 0) { throw "configure rc=$LASTEXITCODE" }
& $cmake --build $bld --config Release --target llama-bench llama-perplexity llama -j 8
if ($LASTEXITCODE -ne 0) { throw "build rc=$LASTEXITCODE" }
New-Item -ItemType Directory -Force $bin | Out-Null
$out = Join-Path $bld 'bin\Release'
Copy-Item (Join-Path $out 'llama-bench.exe') (Join-Path $bin 'llama-bench-temporal.exe') -Force
Copy-Item (Join-Path $out 'llama-perplexity.exe') (Join-Path $bin 'llama-perplexity.exe') -Force
Get-ChildItem $out -Filter *.dll | Copy-Item -Destination $bin -Force
Get-ChildItem $bin | Select-Object Name, Length | Format-Table -AutoSize | Out-String
Get-FileHash (Join-Path $bin 'llama-bench-temporal.exe'), (Join-Path $bin 'llama-perplexity.exe') -Algorithm SHA256 | Format-Table Hash, Path -AutoSize | Out-String -Width 200
"=== $(Get-Date -Format s) BUILD WIN DONE"
